console.log("I got a rainbow!");
console.log("And an extension called Prettify JSON, Panda Theme, npm, and more!")