// Predict 1
// Answer: I was born in1980

// Predict 2
// Answer: I was born in1980

// Predict 3
// Answer:
    // Summing Numbers!
    // num1 is: 10
    // num2 is: 20
    // 30