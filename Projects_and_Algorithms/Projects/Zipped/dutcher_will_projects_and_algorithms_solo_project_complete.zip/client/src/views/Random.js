import React from 'react';

const Random = (props) => {
    return (
        <div>
            <h1>Random</h1>
        </div>
    );
};

export default Random;