import React, { useEffect, useState } from 'react';
import { navigate } from '@reach/router';
import axios from 'axios';
import PageNotFound from './PageNotFound';

const Detail = (props) => {
    const [ author, setAuthor ] = useState();                           // props is the product object (title, price, desc)
    // const [ author, setAuthor ] = useState(null);

    useEffect(() => {                                                       // When the page comes up, run this immediately
        console.log("useEffect() has been run")
        axios.get(`http://localhost:8000/api/authors/${ props.id }`)        // Call GET on products API with the id that was passed in through props
            .then((res) => {
                console.log(res.data)})
            .then((res) => { setAuthor(res.data)
            })
            .catch((err) => {
                console.log(err)
            })
    }, [props.id]);

    if (author === "" || author === null) {
        navigate('/authors')
    };

    if (author === "" || author === null) {
        return (<PageNotFound />)
    };

    return (
        <h1>{author._id}</h1>
        // <div key={ author._id }>
        //     <Link className="d-block text-center" to='/authors/new'>Add an Author</Link>
        //     <table>
        //         <thead>
        //             <th>Author</th>
        //             <th>Actions Available</th>
        //         </thead>
        //         <tr>
        //             <td>{ author.name }</td>
        //             <td className="d-flex">
        //                 <button onClick={ (e) => {
        //                     navigate(`/authors/${ author._id }`)
        //                 }}>
        //                     Edit
        //                 </button>
        //                 <DeleteButton authorId={ author._id } successCallback={ () => { removeFromDom(author._id) }} />
        //             </td>
        //         </tr>
        //     </table>
        // </div>
    );
};

export default Detail;