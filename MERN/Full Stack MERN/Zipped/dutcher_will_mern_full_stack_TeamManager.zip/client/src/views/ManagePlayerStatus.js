import React from 'react';

const ManagePlayerStatus = () => {
    return (
        <div>
            <h1>Manage Player Status</h1>
            <h5>Under Construction</h5>
        </div>
    );
};

export default ManagePlayerStatus;