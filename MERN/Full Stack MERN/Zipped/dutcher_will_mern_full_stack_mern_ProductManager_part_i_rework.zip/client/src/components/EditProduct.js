import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, navigate } from '@reach/router';

const EditProduct = (props) => {
    return (
        <div>
            <h2>Edit Product</h2>
        </div>
    );
};

export default EditProduct;