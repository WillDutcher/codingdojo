import React from 'react'

const FormResults = (props) => {
    const { firstName, lastName, email, password, confPassword } = props.results
    return (
        <div className="resultsContainer">
            <h3>Your Form Results</h3>
            <p className="resultsField"><span className="label">First Name:</span><span className="readOnly">{firstName}</span></p>
            <p className="resultsField"><span className="label">Last Name:</span><span className="readOnly">{lastName}</span></p>
            <p className="resultsField"><span className="label">Email:</span><span className="readOnly">{email}</span></p>
            <p className="resultsField"><span className="label">Password:</span><span className="readOnly">{password}</span></p>
            <p className="resultsField"><span className="label">Confirm Password:</span><span className="readOnly">{confPassword}</span></p>
        </div>
    )
}

export default FormResults;