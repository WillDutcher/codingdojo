import React from 'react';

const UserForm = (props) => {
    const{ formInputs, setFormInputs } = props;

    const onChange = (e) => {
        setFormInputs({
            ...formInputs,
            [e.target.name]: e.target.value
        });
    }

    const createUser = (e) => {
        e.preventDefault();
        alert("New User 'Created' (Not really)");
    };

    return (
        <form onSubmit={createUser}>
            <div className="formContainer">
                <div className="formField">
                    <label htmlFor="firstName">First Name: </label>
                    <input id="firstName" onChange={onChange} type="text" name="firstName" />
                </div>
                <div className="formField">
                    <label htmlFor="lastName">Last Name: </label>
                    <input id="lastName" onChange={onChange} type="text" name="lastName" />
                </div>
                <div className="formField">
                    <label htmlFor="email">Email: </label>
                    <input id="email" onChange={onChange} type="text" name="email" />
                </div>
                <div className="formField">
                    <label htmlFor="password">Password: </label>
                    <input id="password" onChange={onChange} type="password" name="password" />
                </div>
                <div className="formField">
                    <label htmlFor="confPassword">Confirm Password: </label>
                    <input id="confPassword" onChange={onChange} type="password" name="confPassword" />
                </div>
                <div className="btn-div">
                    <button type="submit">Submit</button>
                </div>
            </div>
        </form>
    )
}

export default UserForm;