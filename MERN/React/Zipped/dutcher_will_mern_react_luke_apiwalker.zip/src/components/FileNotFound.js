import React from 'react';

const FileNotFound = () => {
  return (
    <div className="notFound-container">
      <img id="notFound" src="./assets/404_img.jpg" alt="404 Page" />
    </div>
  );
};

export default FileNotFound;