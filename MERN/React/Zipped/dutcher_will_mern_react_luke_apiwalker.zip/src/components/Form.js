import React, { useState } from 'react';
import axios from 'axios';
import { navigate } from '@reach/router';

const Form = ({ setSearchResults }) => {
  const [ getSearchType, setSearchType ] = useState("");
  const [ getID, setID ] = useState("");

  const searchAPI = (e) => {
    e.preventDefault();
    axios.get(`https://swapi.dev/api/${ getSearchType }/${ getID }`)
      .then( (data) => {
        console.log(data);
        setSearchResults(data['data']); // Sets props passed to Results component - pass all returned data
        navigate(`/${ getID }`);        // Nav to page with that specific id, unless...
      })
      .catch( (err) => {
        navigate('/404');         // If error, navigate to error page
      });
  }

  return (    
    <div className="container d-flex justify-content-center">

      <form onSubmit={ searchAPI }>
        <div className="d-flex align-content-center align-items-center"> {/* First Div */}

          <div className="d-flex align-items-center"> {/* Second Div */}
            <label htmlFor="dropdownMenu" className="mr-3">Search:</label>
            <select className="btn btn-secondary btn-group dropdown dropdown-menu dropdown-toggle mr-5 pl-2 position-relative" 
                id="dropdownMenu" data-boundary="dropdownMenu" name="type"
                onChange={ (e) => setSearchType(e.target.value)} value={ getSearchType }>
              <option className="dropdown-item bg-white" value="" disabled></option>
              <option className="dropdown-item bg-white" value="films">Films</option>
              <option className="dropdown-item bg-white" value="people">People</option>
              <option className="dropdown-item bg-white" value="planets">Planets</option>
              <option className="dropdown-item bg-white" value="species">Species</option>
              <option className="dropdown-item bg-white" value="starships">Starships</option>
              <option className="dropdown-item bg-white" value="vehicles">Vehicles</option>
            </select>
          </div> {/* Close Second Div */}

          <div className="d-flex align-items-center"> {/* Third Div */}
            <label htmlFor="idInput" className="mr-3">ID:</label>
            <input type="text" id="idInput" name="idInput" className="mr-5 pl-2"
                onChange={ (e) => setID(e.target.value)} value={ getID }
            />
          </div> {/* Close Third Div */}

          <button id="searchBtn" className="btn">Search</button>

        </div> {/* Close First Div */}
      </form>
    </div>
  );
};

export default Form;