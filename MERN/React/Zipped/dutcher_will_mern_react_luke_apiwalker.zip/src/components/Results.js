import React from 'react';

const Results = ({ getSearchResults }) => {

    const style = {
        fontWeight: "bold",
        color: "blue",
        fontSize: "3em"
    }

    if (getSearchResults) {
        return (
            <div className="results">
                <div className="container">
                    <h3 className="ml-3">{ getSearchResults.name }</h3>
                    {Object.keys(getSearchResults).map((item, index) => 
                        item!== "name" ? (
                            <div className="ml-5 p-0" key={index}>
                                <span className="resultsSpan text-light">{ item }:</span>{" "}
                                <h5 className="ml-3 mb-3">{getSearchResults[item]}</h5>
                            </div>
                        ) :
                        null
                    )}
                </div>
            </div>
        );
    } else {
        return (
            <>
                {/* No results were found; returns blank and redirects to 404 page */}
            </>
        )
    }
};

export default Results;

// 