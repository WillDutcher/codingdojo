import React from "react";
import Form from "./Form";

const Navbar = ({ setSearchResults }) => {
  return (
    <nav className="">
      <div className="p-3 container d-flex align-items-center justify-content-center flex-column">
        <img id="logo" src="./assets/sw_logo.png" alt="Star Wars Logo" />
        <span id="nav-API">API</span>
      </div>
      <div className="container">
        <div className="p-3">
          <Form setSearchResults={ setSearchResults } />
          <hr />
        </div>
      </div>
    </nav>
    );
  };

export default Navbar;