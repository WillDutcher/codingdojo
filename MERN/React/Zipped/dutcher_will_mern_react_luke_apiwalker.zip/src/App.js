import React, { useState } from 'react';
import { Router } from '@reach/router';

import Navbar from './components/Navbar';
import Results from './components/Results';
import FileNotFound from './components/FileNotFound';

import './../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './../node_modules/bootstrap/dist/js/bootstrap.min';
import $ from 'jquery';
import Popper from 'popper.js';
import './App.css';

function App() {
  const [ getSearchResults, setSearchResults ] = useState(null);

  return (
    <div>
      <Navbar setSearchResults={ setSearchResults } />
      <Router>
        <Results path="/:id" getSearchResults={ getSearchResults } />
        <FileNotFound path="/404" />
      </Router>
    </div>
  );
}

export default App;
