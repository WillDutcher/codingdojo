import React, { Component } from 'react';
import styles from './Subcontents.module.css';

class Subcontents extends Component {
    // constructor(props) {
    //     super(props);
    // }
    render() {
        return(
            <>
                <div className={styles.subcontents}></div>
            </>
        )
    }
}

export default Subcontents;