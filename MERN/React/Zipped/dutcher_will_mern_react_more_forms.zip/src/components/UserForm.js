import React from 'react';

const UserForm = (props) => {

    const { formInputs, setFormInputs } = props;

    const emailFormat = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    const passwordCheck = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])(?=.{8,})/;

    const onChange = (e) => {
        setFormInputs({
            ...formInputs,
            [e.target.name]: e.target.value
        });
    }

    const submitUser = (e) => {
        alert("User has been submitted.");
        document.getElementById("myForm").reset();
    }

    return (
        
        <form id="myForm" onSubmit = { (e) => e.preventDefault() }>
            <div className="formContainer">
                <div className="formField">
                    <label htmlFor="firstName">First Name: </label>
                    <input id="firstName" onChange={onChange} type="text" name="firstName" />
                </div>
                <div className="formError">
                    {
                    (props.formInputs.firstName.length < 2 && props.formInputs.firstName.length !== 0) ?
                        <p>Your first name must be at least two letters.</p> :
                        ''
                    }
                </div>
                <div className="formField">
                    <label htmlFor="lastName">Last Name: </label>
                    <input id="lastName" onChange={onChange} type="text" name="lastName" />
                </div>
                <div className="formError">
                    {
                    (props.formInputs.lastName.length < 2  && props.formInputs.lastName.length !== 0) ?
                        <p>Your last name must be at least two letters.</p> :
                        ''
                    }
                </div>
                <div className="formField">
                    <label htmlFor="email">Email: </label>
                    <input id="email" onChange={onChange} type="text" name="email" />
                </div>
                <div className="formError">
                    {
                    (!props.formInputs.email.match(emailFormat) && props.formInputs.email.length !== 0) ?
                        <p>Not a valid email address.</p> :
                        ''
                    }
                </div>
                <div className="formField">
                    <label htmlFor="password">Password: </label>
                    <input id="password" onChange={onChange} type="password" name="password" />
                </div>
                <div className="formError">
                    {
                    (!props.formInputs.password.match(passwordCheck) && props.formInputs.password.length !== 0) ?
                        <div>Your password must contain:
                            <ul>
                                <li>At least one uppercase letter</li>
                                <li>At least one lowercase letter</li>
                                <li>At least one number</li>
                                <li>At least one special character</li>
                            </ul>
                        </div> :
                        ''
                    }
                </div>
                <div className="formField">
                    <label htmlFor="confPassword">Confirm Password: </label>
                    <input id="confPassword" onChange={onChange} type="password" name="confPassword" />
                </div>
                <div className="formError">
                    {
                    props.formInputs.confPassword !== props.formInputs.password ?
                        <p>Your passwords do not match.</p> :
                        ''
                    }
                </div>
                <div className="btn-div">
                    {
                        formInputs.firstName.length > 1
                        && formInputs.lastName.length > 1
                        && emailFormat.test(props.formInputs.email)
                        && passwordCheck.test(props.formInputs.password)
                        && (props.formInputs.confPassword === props.formInputs.password) ?
                            <button type="submit" onClick={ submitUser }>Submit</button> :
                            <button type="submit" disabled>Submit</button>
                    }
                </div>

            </div>
        </form>
    );
}

export default UserForm;