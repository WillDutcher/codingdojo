import React, { useState } from 'react';
import './App.css';
import UserForm from './components/UserForm';

function App() {
  const [state, setState] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confPassword: ""
  });
  return (
    <div className="App">
      <UserForm formInputs={state} setFormInputs={setState} />
    </div>
  );
}

export default App;
