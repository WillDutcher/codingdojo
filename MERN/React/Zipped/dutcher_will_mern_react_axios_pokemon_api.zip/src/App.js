import React, { useState } from 'react';
import axios from 'axios';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './App.css';

function App() {
  const [ pokemon, setPokemon] = useState([]);
  let randomColor = Math.floor(Math.random()*16777215).toString(16);
  let randomColor2 = Math.floor(Math.random()*16777215).toString(16);

    const getPokemon = () => {
      axios.get("https://pokeapi.co/api/v2/pokemon?limit=1118")
      .then(response => {
        console.log(response.data.results);
        setPokemon(response.data.results)
      })
      document.getElementById("myBtn").innerHTML = "Here's your Pokemon!";
    }

  return (
    <div className="App">
      <h2>Axios APIs - Pokedex</h2>
      <div style={{margin: "0 auto"}}>
        <button id="myBtn" className="my-3" onClick={ getPokemon }>Get Pokemon</button>
      </div>
      <div>
        {
          pokemon.map((pokeObj, index) => (
            <ul key={index}>
              <li style={{backgroundColor: "#"+randomColor, color: "#"+randomColor2}}className="p-2 d-inline-block">{index + 1}: {pokeObj.name}</li>
            </ul>
          ))
        }
      </div>
    </div>
  );
}

export default App;
