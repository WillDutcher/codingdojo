import React from 'react';
// import logo from './logo.svg';
import './App.css';

// import {MyNewComponent, AnotherComponent} from './components/MyNewComponent'
// import PersonCard from './components/PersonCard'
// import LightSwitch from './components/LightSwitch'
// import AnotherComponent from './components/MyNewComponent'
import PersonCard2 from './components/PersonCard2';

function App() {
  return (
    <div className="App">
      {/* <MyNewComponent someText={"Hello World!"}/>
      <MyNewComponent someText={"I am reusing this component"}/>
      <AnotherComponent otherText={"I am from another component!"}/> */}
      
      {/* <LightSwitch /> */}
      
      {/* 
      ------ Class Components  ------
      <PersonCard  firstName={"Jane"} lastName={"Doe"} age={45} hairColor={"Black"}/>
      <PersonCard  firstName={"John"} lastName={"Smith"} age={88} hairColor={"Brown"}/>
      <PersonCard  firstName={"Millard"} lastName={"Fillmore"} age={50} hairColor={"Brown"}/>
      <PersonCard  firstName={"Maria"} lastName={"Smith"} age={62} hairColor={"Brown"}/>
      */}

      {/*
      ------ Functional Components------
      */}
      <PersonCard2  firstName={"Jane"} lastName={"Doe"} age={45} hairColor={"Black"}/>
      <PersonCard2  firstName={"John"} lastName={"Smith"} age={88} hairColor={"Brown"}/>
      <PersonCard2  firstName={"Millard"} lastName={"Fillmore"} age={50} hairColor={"Brown"}/>
      <PersonCard2  firstName={"Maria"} lastName={"Smith"} age={62} hairColor={"Brown"}/>
      {/* <button onClick={ () => alert("This button has been clicked!") }>Click Me</button> */}
    </div>
  );
}

export default App;
