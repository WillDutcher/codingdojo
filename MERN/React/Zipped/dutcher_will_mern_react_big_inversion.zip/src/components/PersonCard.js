import React, {Component} from 'react';

class PersonCard extends Component {
    constructor(props) {
        super(props);
        this.state = {
            age: this.props.age
        };
    }
    increaseAge = () => {
        alert(`Happy birthday, ${this.props.firstName}!`);
        this.setState({age: this.state.age + 1})
    }
    render() {
        const {firstName, lastName, age, hairColor} = this.props;
        return (
            <div className="person-card-container">
                <div className="person-card">
                    <div className="person-data">
                        <h1>{lastName}, {firstName}</h1>
                        <p>Age: {this.state.age}</p>
                        <p>hair Color: {hairColor}</p>
                    </div>
                    <button className="bday-btn" onClick = {this.increaseAge}>Birthday Button for {firstName} {lastName}</button>
                </div>
            </div>
        )
    }
}

export default PersonCard