import React from 'react';

const PersonCard2 = props => {
    return (
        <div className="person-card-container">
            <div className="person-card">
                <div className="person-data">
                    <h1>{props.lastName}, {props.firstName}</h1>
                    <p>Age: {props.age}</p>
                    <p>Hair Color: {props.hairColor}</p>
                </div>
            </div>
        </div>
    );
}

export default PersonCard2;