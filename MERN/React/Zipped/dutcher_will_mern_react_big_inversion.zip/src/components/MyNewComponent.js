import React, {Component} from 'react';

class MyNewComponent extends Component {
    render() {
        const {someText} = this.props;
        return (
            <div>
                {someText}
            </div>
        )
    }
}

class AnotherComponent extends Component {
    render() {
        const {otherText} = this.props;
        return (
            <>
                <h1>Example: {otherText}</h1>
            </>
        )
    }
}

export {
    MyNewComponent,
    AnotherComponent
}

// PREVIOUSLY
// export default MyNewComponent;