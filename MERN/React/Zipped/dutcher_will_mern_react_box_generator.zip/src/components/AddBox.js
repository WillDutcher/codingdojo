import React, { useState } from 'react';

const AddBox = (props) => {
    
    // const { setBoxProperties, getBoxProperties, getLength, setLength } = props;
    const { setBoxProperties, getBoxProperties } = props;
    const [ getNewColor, setNewColor ] = useState("");
    const hexColor = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})[\s;]$/i;

    const isColor = (color) => {
        let passedColor = new Option().style;
        passedColor.color = color;
        if (color.charAt(0) === "#" && (color.length === 5 || color.length === 8)) {
            color = color.slice(0, -1);
        }
        if (color === "" || color === null) {
            return false
        }
        if (passedColor.color === color ||
            hexColor.test(color) ||
            hexColor.test(color + ";")) {
                return true
        } else {
            return false
        }        
    };

    const addBox = (e) => {
        e.preventDefault();
        if (!isColor(getNewColor)) {
            alert(`'${getNewColor}' is not a color. Aborting.`)
            setNewColor("");
            return
        }
        setBoxProperties({
            ...getBoxProperties,
            boxColors: [getNewColor, ...getBoxProperties.boxColors]
        });
        setNewColor("");
    };

    return (
        <div>
            <h1>Box Generator</h1>
            <form onSubmit={ addBox }>
                <div>
                    <label htmlFor="boxColor">Color</label>
                    <input 
                        name="color"
                        id="color"
                        className="SAMPLE"
                        placeholder="Enter color or hex"
                        type="text"
                        onChange={ (e) => setNewColor(e.target.value) }
                        value={
                            getNewColor.charAt(getNewColor.length - 1) === ";" ?
                                setNewColor(getNewColor.slice(0, -1)) :
                                getNewColor }
                        />
                        <button>Add Box</button>
                </div>
                {/* <div>
                    <label htmlFor="boxLength">Length</label>
                    <input
                        name="boxLength"
                        id="boxLength"
                        className="SAMPLE"
                        type="text"
                        onChange={ (e) => setLength(e.target.value) }
                        value={ getLength }
                    />
                </div>
                <button>Add Box</button> */}
            </form>
            <hr/>
        </div>
    );
};

export default AddBox;