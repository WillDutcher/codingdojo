import React from 'react';

const Footer = () => {
    return (
        <footer className="my-5">&copy; Will Dutcher, 2021</footer>
    )
}

export default Footer;