// import React, { useState } from 'react';
import React from 'react';

// const DisplayBox = ({ color, getLength }) => {
const DisplayBox = ({ color }) => {
    // const { length } = useState("1000px");
    const boxProps = {
        backgroundColor: [color],
        // width: length + "px",
        width: "88px",
        // height: length + "px",
        height: "88px",
        display: "inline-block",
        border: "1px solid black"
    }
    return (
        
        <div className="box m-1" style={ boxProps }></div>
    );
};

export default DisplayBox;