import React from 'react';

const DisplayBox = ({ color }) => {
    const boxColor = {
        backgroundColor: [color],
        width: "100px",
        height: "100px",
        margin: ".5em .5em 0",
        display: "inline-block",
    };
    return (
        <div
            style={ boxColor }
        ></div>
    )
};

export default DisplayBox;