import React, { useState } from 'react';

const AddBox = ({ setBox, box }) => {
    const [newColor, setNewColor] = useState("");

    const onChange = (e) => {
        setNewColor(e.target.value);                // Assigns value in input box to newColor attribute
    };

    const getColor = () => {
        setBox({
            ...box,                                 // Spread out all the key/values in box object (colors: <color1>, <color2>, etc)
            colors: [...box.colors, newColor],      // Assign the array of colors held in box.colors to colors variable; append the newColor
        });
        setNewColor("");
    };

    return (
        <div>
            <label htmlFor="color">Color: </label>
            <input
                id="color"
                onChange={ onChange }
                type="text"
                className="form-control"
                name="newColor"
                value={ newColor }
            />
            <div class="input-group-append">
                <button onClick={ getColor }>
                    Add Box
                </button>
            </div>
        </div>
    );
};

export default AddBox;