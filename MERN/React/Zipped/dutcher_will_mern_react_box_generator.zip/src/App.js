import React, { useState } from "react";
import AddBox from './components/AddBox';
import DisplayBox from './components/DisplayBox';
import Footer from './components/Footer';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./App.css";

function App() {
    const [getBoxProperties, setBoxProperties] = useState({
        boxColors: [],
    });
    // const [getLength, setLength] = useState("");

    return (
        <div className="App">
            {/* <AddBox getBoxProperties={getBoxProperties} setBoxProperties={setBoxProperties} getLength={getLength} setLength={setLength}/> */}
            <AddBox getBoxProperties={getBoxProperties} setBoxProperties={setBoxProperties} />
            <div>
                {getBoxProperties.boxColors.map((color) => (
                    // <DisplayBox color={ color } getLength={ getLength } />
                    <DisplayBox color={ color } />
                ))}
            </div>
            <Footer />
        </div>
    );
}

export default App;