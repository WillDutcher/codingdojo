import React, { useState } from "react";
import AddBox from './components/AddBox';
import DisplayBox from './components/DisplayBox';
import "./App.css";

function App() {
    const [box, setBox] = useState({
        colors: [],
    });

    return (
        <div className="App">
            <div className="container">
                <h1>Box Generator</h1>
                <AddBox setBox={ setBox } box={ box } />
                <div>
                    {box.colors.map((color) => (
                        <DisplayBox color={ color } />
                    ))}
                </div>
            </div>
        </div>
    );
}

export default App;