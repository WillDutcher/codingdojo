import React from 'react';
import { Link } from '@reach/router';

const Navbar = (props) => {
    
    return (
        <>
            <div className='d-flex justify-content-center p-3'>
                <Link className='navbtn navnar nav btn btn-outline-info text-center px-3 py-1 m-3' to='/'>Blank Page</Link>
                <Link className='navbtn navbar nav btn btn-outline-warning text-center px-3 py-1 m-3' to='/home'>Home</Link>
            </div>
        </>
    )
}

export default Navbar;