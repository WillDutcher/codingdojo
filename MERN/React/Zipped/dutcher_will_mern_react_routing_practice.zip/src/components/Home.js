import React from 'react';

const Home = (props) => {
    console.log(props);

    if (!props.word) {
        return (
            <div>
                <h1 className="results w-100 text-center">Welcome!</h1>
            </div>
        );
    } else if (isNaN(props.word)) {
        return (
            <div>
                <h1 className="text-center m-3">The word is:</h1>
                <h1 className="results w-100 text-center"
                    style=
                    { props.font ?
                        { color: props.font, backgroundColor: props.bg } :
                        null
                    }
                >
                {props.word}
                </h1>
            </div>
        );
    } else {
        return (
            <div>
                <h1 className="text-center m-3">The number is:</h1>
                <h1 className="results w-100 text-center">{props.word}</h1>
            </div>
        );
    }
};

export default Home;