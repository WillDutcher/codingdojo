import React from 'react';
import { Router, Link } from '@reach/router';
import Navbar from './components/Navbar';
import Home from './components/Home';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import './App.css';

function App() {

  return (

    <div className='container w-75'>
      <Navbar />
      <div className="text-center">
        <p>Enter either a word or a number following 'localhost:3000/'</p>
        <p>Example: <i><b>https://localhost:3000/popcorn</b></i></p>
        <p>Example: <i><b>https://localhost:3000/8675309</b></i></p><br/>
        <p>Or try adding a word, slash-color, and another slash-color</p>
        <p>Example: <i><b>https://localhost:3000/lil%20uzi%20vert/pink/purple</b></i></p>
      </div>
      <Router>
        <Home path="/home" />
        <Home path="/:word" />
        <Home path="/:word/:font/:bg" />
      </Router>
    </div>
  );
}

export default App;
