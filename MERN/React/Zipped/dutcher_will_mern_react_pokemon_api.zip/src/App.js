import React from 'react';
import PokeAPI from './components/PokeAPI';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>807 Pokemon</h1>
      <PokeAPI />
    </div>
  );
}

export default App;
