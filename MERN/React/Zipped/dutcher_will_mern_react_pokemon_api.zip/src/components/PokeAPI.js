import React, { useState, useEffect } from 'react';


const PokeAPI = (props) => {
    const [state, setState] = useState(0);

    useEffect(() => {
        fetch('https://pokeapi.co/api/v2/pokemon?limit=807')
        .then(response => {
            return response.json()
        })
        .then(response => {
            setState({
                pokemon: response.results
            })
        })
    }, []);

    return (
        <div>
            {state.pokemon ?
                state.pokemon.map((item, index) => {
                    return (
                        <div key={index} className="pokeDiv">
                            <ul>
                                <li>{index + 1}: {item.name}</li>
                            </ul>
                        </div>
                    )
                    
                }) :
                null
            }
        </div>
    )
}

export default PokeAPI;