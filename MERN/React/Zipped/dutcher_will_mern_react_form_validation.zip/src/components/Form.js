import React, { useReducer } from 'react';

const initialState = {
    fName: '',
    lName: '',
    email: ''
};

const nameFormat = /^(([A-Za-z]+[-']?)*([A-Za-z]+)?\s)+([A-Za-z]+[-']?)*([A-Za-z]+)?$/;
const emailFormat = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

function reducer(state, action) {
    return {
        ...state,
        [action.type]: action.payload
    };
}

// eslint-disable-next-line import/no-anonymous-default-export
export default () => {
    const [state, dispatch] = useReducer(reducer, initialState);

    function handleChange(e) {
        const { name, value } = e.target;
        dispatch({
            type: name,
            payload: value
        });
    }

    const submitForm = (e) => {
        alert("Submitted; can't figure out how to clear.");
    }

    return (
        <form className="container" id="testForm" onSubmit = { (e) => e.preventDefault() }>
            {/* {JSON.stringify(state)} */}
            <div className="form-contents">
                <div className="form-element">
                    <label htmlFor="fName">
                        <p className="label">First Name: </p>
                        <input id="fName"
                            name="fName"
                            value={state.fName}
                            onChange={handleChange}
                        />
                        <div className="formError">
                            {
                                state.fName.length < 3 && state.fName.length > 0 && !state.fName.match(nameFormat)?
                                    <p className="formError">Your first name must contain at least two letters.</p> :
                                    ''
                            }
                        </div>
                    </label>
                </div>
                <div className="form-element">
                    <label htmlFor="lName">
                        <p className="label">Last Name: </p>
                        <input id="lName"
                            name="lName"
                            value={state.lName}
                            onChange={handleChange}
                        />
                        <div className="formError">
                            {
                                (state.lName.length < 2 && state.lName.length > 0 && !state.lName.match(nameFormat)) ?
                                    <p className="formError">Your last name must contain at least two letters.</p> :
                                    ''
                            }
                        </div>
                    </label>
                </div>
                <div className="form-element">
                    <label htmlFor="email">
                        <p className="label">Email: </p>
                        <input id="email"
                            name="email"
                            value={state.email}
                            onChange={handleChange}
                        />
                        <div className="formError">
                            {
                                (!state.email.match(emailFormat) && state.email.length !== 0) ?
                                    <p className="formError">Not a valid email address.</p> :
                                    ''
                            }
                        </div>
                    </label>
                </div>
                <div className="btn-div">
                    {
                        state.fName.length > 1
                        && state.lName.length > 1
                        && emailFormat.test(state.email) ?
                            <input className="submit" type="submit" onClick={submitForm}/> :
                            <input className="submit" type="submit" onClick={submitForm} disabled/>
                    }
                </div>
            </div>
        </form>
    );
}