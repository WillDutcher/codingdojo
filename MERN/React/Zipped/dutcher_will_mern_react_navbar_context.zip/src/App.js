import React, { useState } from 'react';
import Form from './components/Form'
import Navbar from './components/Navbar'
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './App.css';

function App() {
  const [ name, setName ] = useState("");
  let randomColor = Math.floor(Math.random()*16777215).toString(16);
  
  return (
    <div className="App" style={{backgroundColor: "#"+randomColor}}>
      <Navbar name={name} />
      <Form name={name} setName={setName} />
    </div>
  );
}

export default App;
