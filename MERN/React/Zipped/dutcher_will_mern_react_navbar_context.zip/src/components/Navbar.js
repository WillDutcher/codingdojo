import React from 'react';

const Navbar = (props) => {
    const { name } = props;
    let randomColor1 = Math.floor(Math.random()*16777215).toString(16);
    let randomColor2 = Math.floor(Math.random()*16777215).toString(16);
    let randomColor3 = Math.floor(Math.random()*16777215).toString(16);
    let bgColor = "linear-gradient(to bottom right, #" + randomColor1 + ", #" + randomColor2 + ")";

    return (
        <div className="container-fluid p-0">
            <nav style={{backgroundColor: "#"+randomColor1}}className="navbar navbar-expand-lg navbar-light d-flex justify-content-center">
                {
                    name ?
                    <div style={{backgroundImage: bgColor, color: "#"+randomColor3}} className="nav-name name-filled">Hi {name}!</div> :
                    <div style={{backgroundColor: "#"+randomColor2, color: "#"+randomColor3}} className="nav-name name-empty">Please enter your name below</div>
                }
            </nav>
        </div>
    )
}

export default Navbar;