import React from 'react';

const Form = (props) => {
    const { name, setName } = props;
    let randomColor = Math.floor(Math.random()*16777215).toString(16);
    let randomColor2 = Math.floor(Math.random()*16777215).toString(16);

    const submitName = (e) => {
        e.preventDefault();
        setName("");
    }

    return (
        <div className="container">
            <form className="mt-5" onSubmit={ submitName }>
                <div className="formGroup">
                    <label className="control-label mr-3" htmlFor="name">Enter Your Name:</label>
                    <input 
                        type="text"
                        name="name"
                        id="name"
                        className="form-control d-inline-block"
                        onChange={ (e) => setName(e.target.value)}
                        value={ name }
                    />
                    <button style={{backgroundColor: "#"+randomColor, color: "#"+randomColor2}} className="btn btn-sm ml-3">Clear</button>
                </div>
            </form>
        </div>
    );
};

export default Form;