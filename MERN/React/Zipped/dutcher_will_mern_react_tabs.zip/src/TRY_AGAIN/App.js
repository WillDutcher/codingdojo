import React, { useState } from 'react';
import Tab from './components/Tab';
import Display from './components/Display';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './App.css';

function App() {
  const [state, setState] = useState({
    tabs: [],
    active: null
  });
  
  return (
    <div className="container text-center py-3">
      <h1 className="pb-3">Tabs Assignment</h1>
      <Tab state={state} setState={setState} />
      <Display results={state} />
    </div>
  );
};

export default App;