import React, { useState } from "react";

const Tab = (props) => {
    const { state, setState } = props;
    const [ newContent, setNewContent ] = useState("");

    const onChange = (e) => {
        setState({
            ...state,
            [e.target.name]: e.target.value
        });
    }

    console.log(state);

    const addContent = (e) => {
        e.preventDefault();
        setState([
            ...state,
            newContent
        ])
    }
    
    return (
        <div>
            <h2 className="text-center">Tab Component</h2>
            <form className="container">
                <label htmlFor="tabContent">Tab Content</label><br/>
                <textarea
                    id="tabContent"
                    name="tabContent"
                    placeholder="Enter new tab content"
                    className="container tab-content-area"
                    rows="2"
                    cols="38"
                    wrap="soft"
                    onChange={ onChange }
                >
                </textarea><br/>
                <button onClick={ addContent }>Button</button>
            </form>
        </div>
    );
};

export default Tab;