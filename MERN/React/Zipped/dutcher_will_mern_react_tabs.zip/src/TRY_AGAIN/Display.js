import React from 'react';

const Display = () => {
    
    return (
        <div>
            <hr />
            <h2>Display Component</h2>
        </div>
    );
};

export default Display;