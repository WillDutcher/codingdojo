import React, { useState } from 'react';
import TabsForm from './components/TabsForm';
import DisplayTabs from './components/DisplayTabs';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './App.css';

function App() {
  const [state, setState] = useState({
    tabTitle: "",
    tabContent: ""
  });

  return (
    <div className="App">
      <TabsForm formInputs={ state } setFormInputs={ setState } />
      <DisplayTabs />
    </div>
  );
}

export default App;
