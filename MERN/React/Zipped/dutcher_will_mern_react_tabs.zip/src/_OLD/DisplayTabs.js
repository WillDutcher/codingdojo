import React from 'react';

const DisplayTabs = () => {
    return (
        <div className="container text-center">
            <h1>DisplayTabs</h1>
        </div>
    );
};

export default DisplayTabs;