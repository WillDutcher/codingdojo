import React, { useState } from 'react';

const TabsForm = (props) => {
    const { formInputs, setFormInputs } = props;
    const [ getTabName, setTabName ] = useState("");

    const onChange = (e) => {
        setTabName(e.target.value)
        setFormInputs({
            ...formInputs,
            [e.target.name]: e.target.value
        });
    };

    const createTabData = (e) => {
        e.preventDefault();
        alert("Input more code here");
    }

    return (
        <div className="container text-center">
            <h1>TabsForm</h1>
            <form onSubmit={ createTabData }>
                <div>
                    <label htmlFor="addTab">Add New Tab</label>
                    <input
                        type="text"
                        id="addTab"
                        name="addTab"
                        onChange={ onChange }
                        placeholder="Enter a tab name"
                        value={ getTabName }
                    />
                </div>
            </form>
            <p>{ getTabName }</p>
        </div>
    );
};

export default TabsForm;