import React, { useState } from 'react';
import TabsContext from './context/TabsContext';
import Tab from './components/Tab';
import Display from './components/Display';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './App.css';

function App() {
  const [state, setState] = useState({
    tabs: [
      "content is showing here",
      "content is showing here",
      "content is showing here",
      "content is showing here",
      "content is showing here"
    ],
    active: null
  });
  
  return (
    <div className="container text-center py-3">
      <h1 className="pb-3">Tabs Assignment</h1>
      <TabsContext.Provider value={{ state, setState }}>
        <Tab />
        <Display />
      </TabsContext.Provider>
    </div>
  );
};

export default App;