import React, { useContext } from "react";
import TabsContext from "../context/TabsContext";

const Tab = () => {
    // context includes: state (tabs, active) & setState
    const context = useContext(TabsContext);
    console.log(context);


    const defaultStyle = {
        backgroundColor: "white",
        color: "black",
        border: "1px solid black"
    }

    const onClick = (e, i) => {
        let buttons = document.getElementsByClassName("btn btn-light");
        for (let button of buttons) {
            button.style.backgroundColor = "white";
            button.style.color = "black";
            button.style.border = "1px solid black";
        }
        context.setState({
            ...context.state,
            active: i
        });
        e.target.style.backgroundColor = "lightcoral";
        e.target.style.color = "white";
        e.target.style.border = "1px solid pink";
        // set "active" to the index position
    };
    
    return (
        <div className="">
            {context.state.tabs.map((item, i) => (
                <button style={defaultStyle} onClick={ (e) => onClick(e, i)} className="btn btn-light m-1">
                    Tab {i + 1}
                </button>
            ))}
        </div>
    );
};

export default Tab;