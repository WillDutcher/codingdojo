import React, { useContext } from 'react';
import TabsContext from '../context/TabsContext';

const Display = () => {
    // context includes: state (tabs, active) & setState
    const context = useContext( TabsContext );
    const { tabs, active } = context.state;

    return (
        <div className="">
            { active != null ? (
                <div className="mt-3 display-container px-2 py-1">
                    Tab { active + 1 } { tabs[active] }
                </div>
            ) :
            null }
        </div>
    );
};

export default Display;