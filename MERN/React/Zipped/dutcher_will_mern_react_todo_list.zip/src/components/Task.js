import React from 'react';

const Task = (props) => {
    const { task, index, list, setList } = props;

    const onClick = () => {
        setList(() => {
            return list.filter(task => list.indexOf(task) !== index)
        })
    }

    const onChange = (e) => {
        list[index].isComplete = !list[index].isComplete;
        setList([...list]);
        if (list[index].isComplete === true) {
        }
    }

    return (
        <div>
            <div className="container bg-secondary">
                {
                    task.isComplete === true ?
                    <h4 style={{textDecoration: "line-through"}} id="text-danger">{task.name}</h4> :
                    <h4 id="text-danger">{task.name}</h4>
                }
                <div className="container">
                    <label htmlFor="isComplete">Completed?</label>
                    <input className="mx-3" type="checkbox" name="isComplete" id="isComplete" onChange={onChange} checked={task.isComplete}></input>
                    {
                        task.isComplete === true ?
                        <button className="btn btn-danger complete-btn" onClick={onClick}>X</button> :
                        <button disabled className="btn btn-sm btn-danger complete-btn" onClick={onClick}>X</button>
                    }
                </div>
            </div>
        </div>
    );
};

export default Task;