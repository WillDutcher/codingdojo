import React from 'react';

const Input = (props) => {
    const { list, setList } = props;
    let task = {
        name: "",
        isComplete: false
    }

    const onChange = (e) => {
        task.name = e.target.value;
    }

    const onClick = (e) => {
        if (task.name.length === 0) {
            return
        }
        setList([...list, task]); // spread initial list array and add the new task to the array
        e.target.value = ""; // resets target value, but not input field
    };
    
    return (
        <div className="container w-50 mt-3">
            <input
                className="form-control"
                type="text"
                name="task"
                onChange={ onChange }
            />
            <button className="btn btn-primary btn-block mt-1" onClick={ onClick }>
                Add Task
            </button>
        </div>
    )
}

export default Input;