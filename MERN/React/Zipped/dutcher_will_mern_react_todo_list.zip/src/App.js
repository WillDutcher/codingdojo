import React, { useState } from 'react';
import Input from './components/Input';
import Task from './components/Task';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './App.css';

function App() {
  const [ list, setList ] = useState([])
  return (
    <div className="App container tasks">
      {list.map((task, i) => (
        <Task task={task} setList={setList} index={i} list={list} key={i} />
      ))}
      <Input list={list} setList={setList} />
    </div>
  );
}

export default App;
